<?php
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ajax Signup</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
  <div class="container">
  <div class="row">
  <div class="col-md-5 mx-auto mt-5">
  <?php if(isset($_SESSION['created'])): ?>
    <div class="alert alert-success">
    <?php echo $_SESSION['created']; ?>
    </div>
<?php endif; ?>
   <a href="index.php" style="float:right;margin-top:10px;">Create a new account</a>
   <script src="jquery.min.js"</script> 
   <script src="ajexJavascript.js"></script>
</body>
</html>