<!DOCTYPE html>
<html>
<head>

<style>
img {
  width: 100%;
}
</style>
<link rel="stylesheet" href="mystyle.css">
	<title></title>
</head>
<body >


<form action="connection.php" method="post">

</div>
	<p align="center">
				<table align="center">
		<tr>
			<th colspan="2"><h2> Instructor Registration</h2></th>
		</tr>
		
	
		<tr>
			<td>Name</td>
			<td><input type="text" name="sname" required pattern="[a-zA-Z]{3,15}$" ></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="semail" required pattern="[a-zA-Z0-9]+@[a-z0-9.-]+\.[a-z]{2,5}$">
			</td>
		</tr>
		    <tr>
      <td>Password</td>
      <td><input type="password" name="spass" required></td>
     </tr>
		
		<form action="upload.php" method="post" enctype="multipart/form-data">
         <tr>
			<td>Upload Image</td>
			<td align="right" colspan="2"><input type="file" name=" file" value="choose file"> </td>
		</tr>
		<tr>
			<td align="middle" colspan="2"><input type="submit" name="submit" value="send"></td>
		</tr>
		</form>
	</table>

	<center>
		
		 <input type="button" onclick="window.location='Home.php'" class="Redirect" value="Back"/> 
		<input type="button" onclick="window.location='instructor Login.php'" class="Redirect" value="Login"/>

	</center>

</form>

</body>
</html>