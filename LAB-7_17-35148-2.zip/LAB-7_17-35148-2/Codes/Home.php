<?php
?>
 <!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="mystyle.css">

<style>
	@media only screen and (max-width: 600px) 
	{
  body 
  {
    background-color: white;
  }
}

/* For desktop: */
.col-1 {width: 20%;}
.col-2 {width: 50%;}


@media only screen and (max-width: 768px) {
  /* For mobile phones: */
  [class*="col-"] {
    width: 100%;
  }
}
   </style>
<title></title>
</head>

<body >
	<center>
	<div class="col-2 ">

	<h2> Welocme to My page </h2>
</div>
<div class="col-1 ">
	</div>
	<div class="col-2 ">
</div>
<div class="col-1 ">
<input type="button" onclick="window.location='instructor Login.php'" class=  "Redirect" value="Instructor Login"/>
<input type="button" onclick="window.location='instructor Registration.php'" class="Redirect" value="Instructor Registration"/>
</div>
</center>
</body>
</html>