<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="mystyle.css">
  <title></title>
</head>
<body>

<form action="welcome.php" method="post">
  
  <table align="center">
    <tr>
      <th colspan="2"><h2>Change Password </h2></th>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="text" name="semail"></td>
    </tr>
    <tr>
      <td>New Password</td>
      <td><input type="password" name="spass"></td>
    </tr>

    <tr>
      <td align="right" colspan="2"><input type="submit" name="update" value="update"></td>
      
    </tr>
         <tr>
    <td align="right" colspan="2"><input type="submit" name="reset" value="reset"></td>
    </tr>
  </table>
  
</form>

</body>
</html>