
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="mystyle.css">
  <title></title>
</head>
<body >


  <form name="loginform" action="Dashboard.php" method="get">
  
  <table align="center">
    <tr>
      <th colspan="2"><h2> Instructor Login</h2></th>
    </tr>
    <tr>

      <td>Name</td>
      <td><input type="text" name="sname" value="<?php if(isset($_COOKIE['sname'])) echo $_COOKIE['sname']; ?>" required pattern="[a-zA-Z]{3,15}$" ></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="password" name="spass" value="<?php if(isset($_COOKIE['spass'])) echo $_COOKIE['spass']; ?>" required></td>
    </tr>
    <tr>
      <td><div class="checkbox"></td>
      <td><input type="checkbox" name="remember me" id="remember me" <?php if(isset($_COOKIE['sname'])){echo "checked='checked'"; } ?> value="1">
        <label for="remember">
          Remember Me
        </label>
      </div>
    </td>  
    </tr>

    <tr>
      <td align="right" colspan="2"><input type="button" onclick="window.location='Dashboard.php'" class="Redirect" value="Login"></td>
      
    </tr>
    <tr>
     <td align="right" colspan="2"><input type="button" onclick="window.location='Home.php'" class="Redirect" value="Back"/></td>
   </tr>
   <tr>
      <td align="right" colspan="2"><input type="button" onclick="window.location='Instructor Registration.php'" class="Redirect" value="Sign Up"/></td>
      

    </tr>

  </table>
  
</form>

</body>
</html>