<?php
?>
 <!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body bgcolor="white">
<center>
	<h2> Welocme to webtech page </h2>
	<h3>  </h3>

<input type="button" onclick="window.location='Manager Login.php'" class="Redirect" value="Manager Login"/>
<input type="button" onclick="window.location='Manager Registration.php'" class="Redirect" value="Manager Registration"/>


</center>
</body>
</html>