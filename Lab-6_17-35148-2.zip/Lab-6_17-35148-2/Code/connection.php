	<?php


      $connect = mysqli_connect("localhost","root","","intructor");
	  if(!$connect){
		  echo("Error connection:".mysqli_connect_error());
	  }
	  if(isset($_POST['submit'])){
		  $sname  = $_POST['sname'];
		  $semail  = $_POST['semail'];	 
		  $spass  = $_POST['spass'];
		   $spass = md5($spass);
		  $sexperiece  = $_POST['sexperiece'];
		 
		  
	$sql = "insert into register(ID,Name,Email,Password,Experience)
	values('', '$sname', '$semail', '$spass','$sexperiece')";
	$result = mysqli_query($connect,$sql);
	
	   if($result){
		   echo"Thanks For your Registration";
	   }
	   else{
		   echo"Please Try again";
	   }
	  }
	>

	<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body bgcolor="white">
</body>
</html>