
<!DOCTYPE html>
<html>
<head>
<style>
/* This style sets the width of all images to 100%: */
img {
  width: 100%;
}
</style>
  <title></title>
</head>
<body bgcolor="white">

<form action="welcome.php" method="post">

</div>
  <table align="center">
    <tr>
      <th colspan="2"><h2> Edit Profile</h2></th>
    </tr>
    <tr>
      <td>Name</td>
      <td><input type="text" name="sname" required pattern="[a-zA-Z]{3,15}$" ></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="text" name="semail required pattern="required pattern="[a-zA-Z0-9]+@[a-z0-9.-]+\.[a-z]{2,5}$"></td>
    </tr>
   
  </table>
  <br>
<center>
      <input type="submit" name="update" value="update">   
    <input type="button" onclick="window.location='Dashboard.php'" class="Redirect" value="Back"/> 
    <input type="button" onclick="window.location='Home.php'" class="Redirect" value="Logout"/>
</center>
</form>
</body>
</html>